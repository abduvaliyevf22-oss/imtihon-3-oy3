#include <stdio.h>
#include <string.h>

struct Student {
    char ism[100];
    int yoshi;
    float bahosi;
};

void display_student(struct Student student) {
    printf("Ism: %s\n", student.ism);
    printf("Yosh: %d\n", student.yoshi);
    printf("O'rtacha baho (bahos): %.2f\n", student.bahosi);
}

int main() {

    struct Student s1;
    strcpy(s1.ism, "Aziz Karimov");
    s1.yoshi = 20;
    s1.bahosi = 3.75;

    struct Student s2 = {"Malika Yusupova",16,5};
    s2.yoshi = 16;
    s2.bahosi = 5;

    display_student(s1);
    display_student(s2);
}