#include <stdio.h>

int main() {
    int a,b;
    int juft_sonlar[100];
    int soni = 0; 
    printf("a va b ni kiriting: ");
    scanf("%d %d", &a, &b);
    for (int i = a; i <= b; i++) {
        if (i % 2 == 0) {
            juft_sonlar[soni] = i;
            soni++;
        }
    }
    printf("Juft son:");
    for (int i = 0; i < soni; i++) {
        printf("%d ", juft_sonlar[i]);
    }
}