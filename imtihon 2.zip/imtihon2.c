#include <stdio.h>

int main() {
    FILE *matnn=fopen("matn.txt","w");
    char matn[3000];
    int kichik = 0;
    int katta = 0;

    printf("Matn kiriting: ");
    fgets(matn, sizeof(matn), stdin);

    for (int i = 0; matn[i] != '\0'; i++) {
        if (matn[i] >= 'a' && matn[i] <= 'z') {
            kichik++;
        }

        if (matn[i] >= 'A' && matn[i] <= 'Z') {
            katta++;
        }
    }
    printf("Kichik harflar soni: %d\n", kichik);
    printf("Katta harflar soni: %d\n", katta);
    fprintf(matnn,matn);
    fclose(matnn);
}