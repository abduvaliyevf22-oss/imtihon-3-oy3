#include <stdio.h>

int sum_of_arr(int *arr, int size) {
    int _sum = 0;  
    for (int i = 0; i < size; i++) {
        if (arr[i] % 3 == 0) {
            _sum += arr[i];
        }
    }
    return _sum;
}
int main() {
    int arr1[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int arr2[] = {10, 15, 20, 21, 30, 7};
    int arr3[] = {2, 4, 5, 8, 11};
    int size1 = sizeof(arr1) / sizeof(arr1[0]);
    int size2 = sizeof(arr2) / sizeof(arr2[0]);
    int size3 = sizeof(arr3) / sizeof(arr3[0]);
    
    printf("1-massivdagi 3 ga karrali sonlar yig'indisi: %d\n", sum_of_arr(arr1, size1));
    printf("2-massivdagi 3 ga karrali sonlar yig'indisi: %d\n", sum_of_arr(arr2, size2));
    printf("3-massivdagi 3 ga karrali sonlar yig'indisi: %d\n", sum_of_arr(arr3, size3));
}